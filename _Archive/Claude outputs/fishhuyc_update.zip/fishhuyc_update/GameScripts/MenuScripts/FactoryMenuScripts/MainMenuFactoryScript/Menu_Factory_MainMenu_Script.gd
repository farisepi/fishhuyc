extends Node2D

@onready var play_btn: Button = $PlayButton
@onready var settings_btn: Button = $SettingsButton
@onready var achiv_btn: Button = $AchivmentsButton
@onready var discord_btn: Button = $DiscordButton
@onready var telegram_btn: Button = $TelegramButton
@onready var tiktok_btn: Button = $TikTokButton
@onready var quit_btn: Button = $QuitButton
@onready var save_btn: Button = $SaveButton
@onready var fps_label: Label = $FPSCounter
@onready var logo_area: TextureRect = $LogoArea
@onready var logo: AnimatedSprite2D = $LogoArea/LogoAnimation
@onready var menu_music: AudioStreamPlayer = $MenuMusic

var logo_float_time: float = 0.0
var logo_original_y: float = 0.0
var logo_original_scale: Vector2 = Vector2.ONE
var can_click_logo: bool = true

const BOX_TEXTURE_PATH: String = "res://GameAssets/Sprites/UserInterfaceSprites/FactoryMenuSprites/FactoryMenuBoxTextures/Menu_Factory_Box_Texture.png"

func _ready() -> void:
	if is_instance_valid(Fade) and Fade.has_method("fade_in"):
		Fade.fade_in()
	
	UISounds.stop_everything_gameplay()
	
	var cam = get_viewport().get_camera_2d()
	if cam:
		cam.position = get_viewport().get_visible_rect().size / 2
	
	GlobalMusic.play_menu_music()

	var config = ConfigFile.new()
	if config.load("user://settings.cfg") == OK:
		Global.camera_sensitivity = config.get_value("camera", "sensitivity", 0.0)
		if config.has_section_key("graphics", "resolution"):
			Global.apply_resolution(int(config.get_value("graphics", "resolution", 0)))
		if config.has_section_key("language", "locale"):
			var locale = config.get_value("language", "locale", "ru")
			TranslationServer.set_locale(locale)
		if config.has_section_key("graphics", "show_fps"):
			Global.show_fps = config.get_value("graphics", "show_fps", false)

	var ui_sounds = get_node_or_null("/root/UISounds")
	if ui_sounds:
		if ui_sounds.has_method("stop_earthquake"):
			ui_sounds.stop_earthquake()
		if ui_sounds.has_method("stop_all_dialog"):
			ui_sounds.stop_all_dialog()

	_apply_fps_visibility()

	var buttons = [play_btn, settings_btn, achiv_btn, discord_btn, telegram_btn, tiktok_btn, quit_btn, save_btn]
	for btn in buttons:
		if btn != null:
			ButtonEffects.setup(btn)

	if tiktok_btn != null:
		if not tiktok_btn.pressed.is_connected(_on_tiktok_button_pressed):
			tiktok_btn.pressed.connect(_on_tiktok_button_pressed)

	if logo:
		logo_original_y = logo.position.y
		logo_original_scale = logo.scale

	if logo_area:
		logo_area.mouse_entered.connect(_on_logo_mouse_entered)
		logo_area.mouse_exited.connect(_on_logo_mouse_exited)
		logo_area.gui_input.connect(_on_logo_gui_input)

func _process(delta: float) -> void:
	if fps_label and fps_label.visible:
		fps_label.text = "FPS: " + str(Engine.get_frames_per_second())
	if logo:
		logo_float_time += delta * 0.5
		logo.position.y = logo_original_y + sin(logo_float_time) * 2.0
		logo.rotation = sin(logo_float_time) * 0.005

func _on_logo_mouse_entered() -> void:
	if not logo:
		return
	var tween = create_tween()
	tween.set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tween.tween_property(logo, "scale", logo_original_scale * 1.05, 0.3)

func _on_logo_mouse_exited() -> void:
	if not logo:
		return
	var tween = create_tween()
	tween.set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tween.tween_property(logo, "scale", logo_original_scale, 0.3)

func _on_logo_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if not can_click_logo:
			return
		can_click_logo = false
		var click_sound = AudioStreamPlayer.new()
		add_child(click_sound)
		click_sound.stream = preload("res://GameAssets/Audio/SoundEffects/UserInterfaceSounds/LogoClickSounds/Menu_MainMenu_Aquarium_MainMenu_LogoClick_SoundEffect.mp3")
		click_sound.volume_db = -18.0
		click_sound.pitch_scale = randf_range(0.98, 1.02)
		click_sound.play()
		_logo_jelly_effect()
		_spawn_logo_boxes()
		await get_tree().create_timer(2.5).timeout
		can_click_logo = true

func _logo_jelly_effect() -> void:
	if not logo:
		return
	_kill_tween(logo, "jelly_tween")
	var hover_scale = logo_original_scale * 1.05
	var tween = create_tween()
	tween.set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	tween.tween_property(logo, "scale", Vector2(hover_scale.x * 0.96, hover_scale.y * 1.04), 0.1)
	if logo_area.get_global_rect().has_point(get_global_mouse_position()):
		tween.tween_property(logo, "scale", hover_scale, 0.15)
	else:
		tween.tween_property(logo, "scale", logo_original_scale, 0.15)
	logo.set_meta("jelly_tween", tween)

func _kill_tween(node: Node, key: String) -> void:
	if node.has_meta(key):
		var t: Tween = node.get_meta(key)
		if t and t.is_valid():
			t.kill()

func _apply_fps_visibility() -> void:
	var config = ConfigFile.new()
	config.load("user://settings.cfg")
	if fps_label:
		fps_label.visible = config.get_value("graphics", "show_fps", false)
		fps_label.add_theme_font_size_override("font_size", 14)
		fps_label.add_theme_color_override("font_color", Color.WHITE)
		fps_label.position = Vector2(10, 10)
		fps_label.z_index = 999

func _goto_scene(path: String) -> void:
	if is_instance_valid(Fade):
		Fade.fade_out()
		await get_tree().create_timer(0.3).timeout
	Global.goto_scene(path)

func _on_play_button_pressed() -> void:
	UISounds.play_click()
	Global.came_from = Global.MenuSource.MAIN_MENU
	Global.is_new_game = true
	Global.intro_completed = false
	Global.prologue1_completed = false
	Global.prologue2_completed = false
	_goto_scene("res://GameScenes/MenuScenes/FactoryMenuScenes/FactorySavesMenuScene/Menu_Factory_SavesMenu_Scene.tscn")

func _on_settings_button_pressed() -> void:
	UISounds.play_click()
	Global.came_from = Global.MenuSource.MAIN_MENU
	_goto_scene("res://GameScenes/MenuScenes/FactoryMenuScenes/FactorySettingMenuScene/Menu_Factory_SettingMenu_Scene.tscn")

func _on_achivments_button_pressed() -> void:
	UISounds.play_click()
	Global.came_from = Global.MenuSource.MAIN_MENU
	_goto_scene("res://GameScenes/MenuScenes/FactoryMenuScenes/FactoryAchievementMenuScene/Menu_Factory_AchievementMenu_Scene.tscn")

func _on_save_button_pressed() -> void:
	UISounds.play_click()
	Global.came_from = Global.MenuSource.MAIN_MENU
	Global.is_new_game = false
	_goto_scene("res://GameScenes/MenuScenes/FactoryMenuScenes/FactorySavesMenuScene/Menu_Factory_SavesMenu_Scene.tscn")

func _on_discord_button_pressed() -> void:
	UISounds.play_click()
	OS.shell_open("https://discord.gg/64CKW4kXrq")

func _on_telegram_button_pressed() -> void:
	UISounds.play_click()
	OS.shell_open("https://t.me/fishslaves")

func _on_tiktok_button_pressed() -> void:
	UISounds.play_click()
	OS.shell_open("https://www.tiktok.com/@fish.slaves.official")

func _on_quit_button_pressed() -> void:
	UISounds.play_click()
	if is_instance_valid(Fade):
		Fade.fade_out()
		await get_tree().create_timer(0.3).timeout
	get_tree().quit()



func _spawn_box_fall(box_count: int, kill_after: float) -> void:
	var box_texture = load(BOX_TEXTURE_PATH)
	if not box_texture:
		return
	
	var canvas = CanvasLayer.new()
	canvas.layer = 199
	add_child(canvas)
	
	var view_size = get_viewport().get_visible_rect().size
	
	for i in range(box_count):
		_create_falling_catchable_box(canvas, box_texture, view_size)
		var delay = randf_range(0.0, 0.15)
		await get_tree().create_timer(delay).timeout
	
	await get_tree().create_timer(kill_after).timeout
	if is_instance_valid(canvas):
		canvas.queue_free()

func _create_falling_catchable_box(canvas: CanvasLayer, box_texture: Texture2D, view_size: Vector2) -> void:
	var box = Area2D.new()
	box.input_pickable = true
	box.z_index = 50
	canvas.add_child(box)
	
	var spr = Sprite2D.new()
	spr.texture = box_texture
	var s = randf_range(0.6, 1.5)
	spr.scale = Vector2(2.0, 2.0) * s
	box.add_child(spr)
	
	var col = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = Vector2(spr.texture.get_width(), spr.texture.get_height()) * spr.scale
	col.shape = shape
	box.add_child(col)
	
	box.position = Vector2(randf_range(0, view_size.x), -100.0 - randf_range(0, 200))
	box.rotation = randf_range(-0.6, 0.6)
	
	var fall_duration = randf_range(1.2, 2.5)
	var target_y = view_size.y + 150.0
	var sway_x = randf_range(-70.0, 70.0)
	
	box.input_event.connect(func(_v, event, _idx):
		if event is InputEventMouseButton:
			if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
				_on_caught_box(box, spr)
	)
	
	var tween = box.create_tween()
	tween.set_parallel(true)
	tween.tween_property(box, "position:y", target_y, fall_duration).set_ease(Tween.EASE_IN)
	tween.tween_property(box, "position:x", box.position.x + sway_x, fall_duration)
	tween.tween_property(box, "rotation", box.rotation + randf_range(-3.0, 3.0), fall_duration)

func _on_caught_box(box: Area2D, _spr: Sprite2D) -> void:
	if not is_instance_valid(box):
		return
	
	box.set_deferred("input_pickable", false)
	
	var catch_tween = create_tween()
	catch_tween.set_parallel(true)
	catch_tween.tween_property(box, "scale", Vector2(0.3, 0.3), 0.3).set_ease(Tween.EASE_IN)
	catch_tween.tween_property(box, "modulate:a", 0.0, 0.3)
	catch_tween.tween_property(box, "position:y", box.position.y - 80, 0.3).set_ease(Tween.EASE_OUT)
	
	await catch_tween.finished
	if is_instance_valid(box):
		box.queue_free()
	
	var was_unlocked = Achievements.acrobat_unlocked
	Achievements.unlock_acrobat()
	
	if not was_unlocked:
		_show_acrobat_achievement()



func _spawn_logo_boxes() -> void:
	_spawn_box_fall(3, 2.5)



func _show_acrobat_achievement() -> void:
	# the popup comes from the Achievements autoload now; here only the extra effect
	_spawn_box_fall(12, 4.5)

func _show_rebel_achievement() -> void:
	# the popup comes from the Achievements autoload now; here only the extra effect
	_spawn_box_fall(12, 4.5)
